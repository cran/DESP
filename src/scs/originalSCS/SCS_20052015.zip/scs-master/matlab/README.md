To install scs for matlab, in the scs/matlab directory enter

    make_scs

at the matlab prompt. To install for cvx use
    
    cvx_install_scs
