function l = getSdConeSize(n)
 l = n * (n + 1) / 2;
end