#include "constants.h"

const char * scs_version(void) {
    return SCS_VERSION;
}

